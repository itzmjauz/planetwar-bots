## @namespace PlanetWarsAPI
# Python version of the API
#
# Contains _planet.Planet and _planetwars.PlanetWars
from ._planet import Planet
from ._planetwars import PlanetWars
